package com.user.user_service1.service;

import com.user.user_service1.entity.User;

public interface UserService {
	
	public User getUser(Long id);

}
